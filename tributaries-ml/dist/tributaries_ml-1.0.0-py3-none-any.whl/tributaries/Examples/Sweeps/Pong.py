from tributaries import my_sweep, my_plots


# Launching

# List of hyperparams to launch
my_sweep.hyperparams = [
    f"""task=atari/pong
    experiment=Pong
    log_media=true
    """,

    f"""task=dmc/cheetah_run
    experiment=cheetah
    log_media=false
    """
]

my_sweep.mem = 60

# Plotting

my_plots.plots.append(['Pong', 'cheetah'])  # Lists of experiments to plot together, supports regex .*!
my_plots.title = 'Atari Pong'
