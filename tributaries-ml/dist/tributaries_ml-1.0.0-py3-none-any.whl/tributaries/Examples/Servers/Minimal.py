from tributaries import my_server


@my_server()
def main():
    server, username, password = 'slurm', 'slerman', ''

    return server, username, password


if __name__ == '__main__':
    main()
